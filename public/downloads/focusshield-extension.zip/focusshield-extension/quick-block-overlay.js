(() => {
  const HOST_ID = "focusshield-quick-block-overlay";
  const PROTECTED = ["mysession.club", "my-session.vercel.app"];
  const hostname = location.hostname.replace(/^www\./, "").toLowerCase();
  if (!hostname || PROTECTED.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`))) return;
  if (document.getElementById(HOST_ID)) return;

  const host = document.createElement("div");
  host.id = HOST_ID;
  host.style.setProperty("all", "initial", "important");
  host.style.setProperty("position", "fixed", "important");
  host.style.setProperty("right", "18px", "important");
  host.style.setProperty("bottom", "18px", "important");
  host.style.setProperty("z-index", "2147483647", "important");
  host.style.setProperty("display", "none", "important");
  host.style.setProperty("visibility", "visible", "important");
  host.style.setProperty("pointer-events", "auto", "important");

  const shadow = host.attachShadow({ mode: "closed" });
  shadow.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }
      .wrap {
        position: relative;
        display: flex;
        align-items: center;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        filter: drop-shadow(0 10px 22px rgba(0, 0, 0, .22));
      }
      button {
        appearance: none;
        border: 0;
        margin: 0;
        font: inherit;
        cursor: pointer;
        -webkit-tap-highlight-color: transparent;
      }
      .block {
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 46px;
        height: 46px;
        padding: 0 14px;
        overflow: hidden;
        border-radius: 15px;
        background: #81db86;
        color: #102013;
        font-size: 13px;
        font-weight: 750;
        letter-spacing: -.01em;
        white-space: nowrap;
        transition: transform .16s ease, background .16s ease, box-shadow .16s ease;
        box-shadow: 0 0 0 1px rgba(16, 32, 19, .08);
      }
      .block:hover { background: #91e596; transform: translateY(-1px); }
      .block:active { transform: scale(.97); }
      .block:disabled { cursor: wait; opacity: .8; }
      .icon {
        display: grid;
        flex: 0 0 20px;
        width: 20px;
        height: 20px;
        place-items: center;
        border-radius: 7px;
        background: rgba(16, 32, 19, .11);
      }
      .icon svg { display: block; width: 13px; height: 13px; }
      .label { max-width: 140px; overflow: hidden; transition: max-width .2s ease, opacity .2s ease; }
      .block.success { background: #81db86; }
      .block.error { background: #f1d37b; color: #312600; }
      @media (max-width: 520px) {
        .block { width: 46px; padding: 0 13px; }
        .label { max-width: 0; opacity: 0; }
      }
      @media (prefers-reduced-motion: reduce) {
        .block, .label { transition: none; }
      }
    </style>
    <div class="wrap">
      <button class="block" type="button" title="Block ${hostname} with FocusShield" aria-label="Block this site with FocusShield">
        <span class="icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none"><path d="M12 3 20 6.5v5.2c0 5.1-3.2 8.1-8 9.8-4.8-1.7-8-4.7-8-9.8V6.5L12 3Z" stroke="currentColor" stroke-width="2"/><path d="m8.2 15.8 7.6-7.6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="9" cy="9" r="1" fill="currentColor"/><circle cx="15" cy="15" r="1" fill="currentColor"/></svg>
        </span>
        <span class="label">Block this site</span>
      </button>
    </div>`;

  const button = shadow.querySelector(".block");
  const label = shadow.querySelector(".label");
  let resetTimer = null;

  function setState(text, tone = "") {
    label.textContent = text;
    button.classList.toggle("success", tone === "success");
    button.classList.toggle("error", tone === "error");
    clearTimeout(resetTimer);
    if (tone === "error") {
      resetTimer = setTimeout(() => {
        label.textContent = "Block this site";
        button.classList.remove("error");
      }, 2600);
    }
  }

  button.addEventListener("click", async (event) => {
    event.preventDefault();
    event.stopPropagation();
    if (button.disabled) return;
    button.disabled = true;
    setState("Blocking…");
    try {
      const response = await chrome.runtime.sendMessage({ type: "QUICK_BLOCK_SENDER_TAB" });
      if (!response?.ok) throw new Error(response?.error || "quick_block_failed");
      setState("Blocked ✓", "success");
    } catch (error) {
      const unavailable = String(error?.message || error).includes("context invalidated");
      setState(unavailable ? "Reload this page" : "Couldn’t block", "error");
      button.disabled = false;
    }
  }, true);

  function mountOverlay() {
    const parent = document.fullscreenElement || document.documentElement || document.body;
    if (parent && host.parentNode !== parent) parent.appendChild(host);
  }

  function applyOverlayVisibility(visible) {
    host.style.setProperty("display", visible ? "block" : "none", "important");
  }

  chrome.storage.local.get(["showQuickBlockOverlay"]).then((settings) => {
    applyOverlayVisibility(settings.showQuickBlockOverlay !== false);
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.showQuickBlockOverlay) return;
    applyOverlayVisibility(changes.showQuickBlockOverlay.newValue !== false);
  });
  document.addEventListener("fullscreenchange", mountOverlay, true);
  mountOverlay();
})();